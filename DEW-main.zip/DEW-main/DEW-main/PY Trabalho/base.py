from flask import Flask, render_template, request, redirect, url_for , flash
from flask_wtf import FlaskForm # import FlaskForm from flask_wtf que faz 
from dotenv import load_dotenv #gerencia chaves de ambiente
from wtforms import StringField, PasswordField, SubmitField
from wtforms.validators import DataRequired, Email, Length, EqualTo
import os
from supabase import create_client, Client
from werkzeug.utils import secure_filename

# 1. Carrega as variáveis do arquivo .env
load_dotenv()

#conecção com o supabase
SUPABASE_URL = os.getenv('SUPABASE_URL')
SUPABASE_KEY = os.getenv('SUPABASE_KEY')

# Cria o cliente do Supabase  
supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY) 

#formulario de cadastro
class CadastroForm(FlaskForm):
    PrimeiroNome = StringField('Primeiro Nome', validators=[DataRequired(), Length(min=2, max=30)])
    Sobrenome = StringField('Sobrenome', validators=[DataRequired(), Length(min=2, max=30)])
    CPF = StringField('CPF', validators=[DataRequired(), Length(min=11, max=14)])
    Email = StringField('Email', validators=[DataRequired(), Email(message='Email inválido')])
    Senha = PasswordField('Senha', validators=[DataRequired(), Length(min=6), EqualTo('ConfirmarSenha', message='As senhas devem ser iguais')])
    ConfirmarSenha = PasswordField('Confirmar Senha', validators=[DataRequired(), EqualTo('Senha', message='As senhas devem ser iguais')])
    Submit = SubmitField('Cadastrar')
#fim do formulario de cadastro


#formulario de login
class Login_F(FlaskForm):
    Email = StringField('Email', validators=[DataRequired(), Email(message='Email inválido')])
    Senha = PasswordField('Senha', validators=[DataRequired(), Length(min=6)])
    Submit = SubmitField('Login')
#fim do formulario de login

    

# Initialize Flask app
app = Flask(__name__)
# Ensure SECRET_KEY exists for Flask-WTF CSRF
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY') or 'dev-secret-key'
#inicio da rota princiapal/ inicial
@app.route('/')
def main():
    return render_template('testgratis.html')
#Fim da rota principal

#Iniciando a rota de cadastro
@app.route('/templates/cadastro.html', methods=['GET', 'POST'])

def cadastro():
    form = CadastroForm()
    
    if form.validate_on_submit():
        # Coleta os dados do formulário
        primeiro_nome = form.PrimeiroNome.data
        sobrenome = form.Sobrenome.data
        cpf = form.CPF.data
        email = form.Email.data
        senha = form.Senha.data
        
        # Insere os dados no Supabase
        data = {
            'PrimeiroNome': primeiro_nome,
            'SobreNome': sobrenome,
            'CPF': cpf,
            'Email': email,
            'Senha': senha
        }
        try:
            response = supabase.table('Usuários').insert(data).execute()
            
            return redirect(url_for('login'))
        except Exception as e:
            return f'Erro ao conectar com o banco de dados: {e}'
    return render_template('cadastro.html', form=form)
#Fim da rota de cadastro


#Iniciando a rota de login
@app.route('/templates/login.html', methods=['GET','POST'])
def login():
    form = Login_F()
    
    if form.validate_on_submit():
        email = form.Email.data
        senha = form.Senha.data
        
        try:
            # Consulta no Supabase
            response = supabase.table('Usuários').select('*').eq('Email', email).eq('Senha', senha).execute()
            usuarios = response.data # Isso é uma lista: [] se vazio, ou [{...}] se achou
            
            # Verificação correta: se a lista 'usuarios' tiver algo dentro, o login é válido
            if usuarios: 
                return render_template('home.html')
            else:
                return redirect(url_for('login'))
                
        except Exception as e:
            return f"Erro de conexão: {e}"
    
    # Se o formulário não for válido (ou se for apenas carregar a página), mostra os erros se houver
    if form.errors:
        print("Erros de validação:", form.errors)

    return render_template('login.html', form=form)
#Fim da rota de login    
@app.route('/templates/home.html')
def home():
    return render_template('home.html') 


# Rota de Cadastro de Produto
@app.route('/novo_produto', methods=['GET', 'POST'])
def novo_produto():
    if request.method == 'POST':
        # 1. Captura os dados de texto
        nome_time = request.form['nome_time']
        ano = request.form['ano']
        tamanho = request.form['tamanho']
        quantidade = request.form['quantidade']
        modelo = request.form['modelo']
        
        # 2. Captura o arquivo de imagem
        arquivo = request.files['imagem_produto']
        url_imagem = "" 

        try:
            if arquivo:
                nome_arquivo = secure_filename(arquivo.filename)
                arquivo_bytes = arquivo.read()
                
                # CONFIGURAÇÃO:
                # Bucket = 'imagens_produtos'
                # Pasta interna = 'camisas/'
                caminho_storage = f"camisas/{nome_arquivo}"
                
                # Envia para o bucket 'imagens_produtos'
                supabase.storage.from_('imagens_produtos').upload(
                    path=caminho_storage, 
                    file=arquivo_bytes, 
                    file_options={"content-type": arquivo.content_type}
                )
                
                # Pega o link público do bucket 'imagens_produtos'
                url_imagem = supabase.storage.from_('imagens_produtos').get_public_url(caminho_storage)
            
            # 3. Cria o dicionário para o banco
            data_produto = {
                'NomeTime': nome_time,
                'Ano': int(ano),
                'Tamanho': tamanho,
                'Quantidade': int(quantidade),
                'Modelo': modelo,
                'ImagemURL': url_imagem
            }

            response = supabase.table('Produtos').insert(data_produto).execute()
            
            return redirect(url_for('novo_produto'))
            
        except Exception as e:
            return f"Erro ao cadastrar (Storage ou Banco): {e}"
    
    return render_template('novo_produto.html')


# --- Rota de Consulta ---
@app.route('/consulta', methods=['GET'])
def consulta():
    # Pega o termo digitado na busca (name="q" no HTML)
    termo = request.args.get('q')
    
    lista_exibida = []

    try:
        if termo:
            # Se tem pesquisa, busca no Supabase filtrando pela coluna 'NomeTime'
            # ilike faz uma busca que ignora maiúsculas/minúsculas (case-insensitive)
            # O f'%{termo}%' serve para buscar o texto em qualquer parte do nome
            response = supabase.table('Produtos').select('*').ilike('NomeTime', f'%{termo}%').execute()
        else:
            # Se não tem pesquisa, busca TODOS os produtos
            response = supabase.table('Produtos').select('*').execute()
        
        # O Supabase retorna os dados dentro de response.data
        lista_exibida = response.data

    except Exception as e:
        print(f"Erro ao buscar dados no Supabase: {e}")
        lista_exibida = []

    # Renderiza o template enviando a lista e o termo pesquisado
    # Importante: termo if termo else "" evita enviar None para o HTML
    return render_template('estoque.html', lista_produtos=lista_exibida, termo_pesquisa=termo if termo else "")

@app.route('/editar-produto', methods = ["POST", "PUT"])
def editar_produto():
    metodo = request.form.get("_method", "POST").upper()

    if metodo == "PUT":
        id_produto = request.form['id']
        tamanho = request.form['tamanho']
        quantidade = request.form['quantidade']

        supabase.table('Produtos').update({
            'Tamanho': tamanho,
            'Quantidade' : int(quantidade)
        }).eq('id',id_produto).execute()
        flash("Produto atualizado com sucesso.", "success")  # Trará a mensagem caso o produto seja alterado 
    return redirect(url_for('consulta'))
#--- Rota de Exclusão ---
@app.route('/excluir-produto', methods = ["POST"])
def excluir_produto():
    # Verifica se o método simulado é DELETE
    metodo = request.form.get("_method", "POST").upper()
    
    if metodo == "DELETE":
        id_produto = request.form['id']
        
        try:
            # Comando para deletar no Supabase onde o 'id' corresponde
            supabase.table('Produtos').delete().eq('id', id_produto).execute()
            
            flash("Produto excluído com sucesso.", "success")
            
        except Exception as e:
            flash(f"Erro ao excluir produto: {e}", "danger")
            
    return redirect(url_for('consulta'))
if __name__ == '__main__':
    app.run(debug=True)
